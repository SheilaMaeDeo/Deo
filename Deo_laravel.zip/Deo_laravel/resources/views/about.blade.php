@extends('layouts.app2')

@section("content")
    <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
        	<h1>ALL ABOUT ME</h1>

              <div class="panel panel-default">
              	<H5>
  				 I am Sheila Mae Pasilan Deo from Bantayan Island, Cebu.<BR><BR>
  				 I came from a middle class family that are filled with love by our parents.<BR><BR> 
  				 I have two younger brothers and I am the eldest and only daughter in our family.<BR><BR>
				 I have these following attitudes that symbolizes myself with fear to good, respect to those people older than me, an honest and helpful person, friendly to anyone, a true friend, but sometimes a little bit shy to others, a simple person with a fragile and soft heart.<BR><BR>
				 I have plenty of dreams in my life ever since I was a kid until now.<BR><BR> 
				 First during my childhood and teenager days.<BR><BR> 
				 I dream to become a General Doctor because I really love studying and inventing things related in Science.<BR><BR> 
				 I really idolize those people who wear white coat and goggles.<BR><BR> 
				 But when I go to college I released that it’s very awesome if I take up courses that involves in the world of technologies.<BR><BR> 
				 I really idolize those famous and richest programmers like Bill Gates, Steve Jobs and Mark Zuckerbergh.<BR><BR> 
				 I am always thinking on how famous developers and programmers developed an applications and websites that runs both in IOS and Android so<BR><BR> 
				 I decided to take up Bachelor of Science in Information Technology because<BR><BR> 
				 I wanted to make one of that platform with my own. So for now I am in my last semester as an Information Technology student my first step on reaching my goal to become a Programmer.
              </H5>
              </div>
            </div>
        </div>
    </div>
</div>

@stop